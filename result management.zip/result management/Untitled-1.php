<html>
    <head>
        <title>php file create/write example</title>
    </head>
    <body>
        <from method="post">
            <h3>reading and writing a file</h3>
            enter string:<input type="text"
            name="name"><br/><br/><input type="submit"
            name="submit1"value="write file"><input type="submit"
            name="submit2"value="read file"></form>
            <?php if(isset($_post['submit']))
            {
                $myfile=fopen("abc.txt","a")
                $text=$_post["name"];
                fwrite($myfile,$text);
                fclose($myfile);
            }
            if(isset($_post['submit2']))
            {
                $myfile=fopen("abc,txt","r");
                echo fogets($myfile);
                fclose($myfile);
            }
            ?>
            