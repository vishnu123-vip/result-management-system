<html>
    <head>
        <title>php file create/write</title>
    </head>
    <body>
        <form method="post">
            <h3>file read & write</h3>
            <input type="text" name="text" placeholder="enter text" required>
            <button name="write">write</button>
            <button name="read">read</button>
        </form>
        <?php
        $file="abc,text";
        if(isset($_post['write']))file_put.contents($file,$_post["text"]"\n",file_append);
        if(isset($_post['read'])&&file_existes($file))echo"<h4>file content:</h4>".n12br(file_get_contents($file));
        ?>
        </body>
        </html>